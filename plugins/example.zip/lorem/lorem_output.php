<?php
function lorem_output($values) {
   /**
	* $type = '1';
	*
	* This function will be called on each message and can be used to format events.
	*
	* @param	array	$values		Message event values returned from the database.
	*
	*/
}
?>