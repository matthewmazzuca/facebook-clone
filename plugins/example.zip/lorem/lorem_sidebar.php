<?php
function lorem_sidebar($values) {
   /**
	* $type = '2';
	*
	* This function will be called on the sidebar on the feed page.
	*
	* @param	array	$values		Site and logged-in user information.
	*
	*/
	
   /**
	* $type = '3';
	*
	* This function will be called on the sidebar on the profile page.
	*
	* @param	array	$values		Site and profile user information.
	*
	*/
}
?>